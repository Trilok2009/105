#### Create a new file in a folder with .py extension.
#### You can run the code by typing python filename.py in the command prompt.
#### Remeber to be in the correct path while execution. 
#### Trace path using cd name for changing directory.
